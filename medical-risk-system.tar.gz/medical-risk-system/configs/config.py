"""
configs/config.py
Central configuration for the Multimodal Medical Risk Assessment System.
"""

from dataclasses import dataclass, field
from typing import List, Optional
import os


@dataclass
class ModelConfig:
    # BioBERT
    biobert_model_name: str = "dmis-lab/biobert-base-cased-v1.2"
    biobert_max_length: int = 512
    biobert_hidden_size: int = 768

    # BiomedCLIP (via OpenCLIP)
    biomedclip_model_name: str = "hf-hub:microsoft/BiomedCLIP-PubMedBERT_256-vit_base_patch16_224"
    biomedclip_image_size: int = 224
    biomedclip_embed_dim: int = 512

    # Rad-VLP (uses BiomedCLIP backbone variant)
    radvlp_model_name: str = "microsoft/rad-dino"
    radvlp_embed_dim: int = 768

    # GARD Risk Enrichment
    gard_disease_file: str = "configs/gard_diseases.json"

    # Fusion
    fusion_type: str = "attention"          # "concat" | "attention"
    fusion_hidden_dim: int = 512
    fusion_num_heads: int = 8
    fusion_dropout: float = 0.1

    # Prediction Head
    num_disease_classes: int = 14           # CheXpert 14-class labelling
    disease_labels: List[str] = field(default_factory=lambda: [
        "No Finding", "Enlarged Cardiomediastinum", "Cardiomegaly",
        "Lung Opacity", "Lung Lesion", "Edema", "Consolidation",
        "Pneumonia", "Atelectasis", "Pneumothorax", "Pleural Effusion",
        "Pleural Other", "Fracture", "Support Devices"
    ])

    # Runtime
    device: str = "cpu"
    fp16: bool = False
    cache_dir: Optional[str] = os.getenv("MODEL_CACHE_DIR", "./model_cache")


@dataclass
class PreprocessingConfig:
    image_size: int = 224
    image_mean: List[float] = field(default_factory=lambda: [0.48145466, 0.4578275, 0.40821073])
    image_std: List[float] = field(default_factory=lambda: [0.26862954, 0.26130258, 0.27577711])
    max_symptom_length: int = 512


@dataclass
class APIConfig:
    host: str = "0.0.0.0"
    port: int = 7860
    api_version: str = "v1"
    title: str = "Multimodal Medical Risk Assessment API"
    description: str = "Production-ready medical AI system using BioBERT, BiomedCLIP, Rad-VLP, and GARD enrichment."
    cors_origins: List[str] = field(default_factory=lambda: ["*"])


@dataclass
class AppConfig:
    model: ModelConfig = field(default_factory=ModelConfig)
    preprocessing: PreprocessingConfig = field(default_factory=PreprocessingConfig)
    api: APIConfig = field(default_factory=APIConfig)
    log_level: str = "INFO"
    enable_explainability: bool = True
    enable_gard_enrichment: bool = True


# Singleton
APP_CONFIG = AppConfig()
