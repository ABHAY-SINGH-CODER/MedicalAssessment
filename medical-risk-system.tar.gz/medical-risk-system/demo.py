"""
demo.py
Quick smoke-test / demo script.
Run: PYTHONPATH=. python demo.py
"""

import base64
import io
import json
import sys
import time

import numpy as np
from PIL import Image, ImageDraw


def make_synthetic_xray(width: int = 256, height: int = 256) -> Image.Image:
    """
    Generate a synthetic chest X-ray-like grayscale image for demo purposes.
    """
    img = Image.new("RGB", (width, height), color=(30, 30, 30))
    draw = ImageDraw.Draw(img)

    # Ribcage outline
    for i in range(6):
        y = 40 + i * 30
        draw.arc([20, y, width - 20, y + 40], start=0, end=180, fill=(140, 140, 140), width=2)

    # Lung fields
    draw.ellipse([30, 50, width // 2 - 10, height - 60], outline=(160, 160, 160), width=2)
    draw.ellipse([width // 2 + 10, 50, width - 30, height - 60], outline=(160, 160, 160), width=2)

    # Heart silhouette
    draw.ellipse([width // 2 - 30, height // 2 - 40, width // 2 + 20, height // 2 + 40],
                 fill=(80, 80, 80))

    # Simulate consolidation / opacity in right lower lobe
    draw.ellipse([width // 2 + 20, height - 100, width - 40, height - 40],
                 fill=(110, 110, 110))

    return img


def image_to_b64(img: Image.Image) -> str:
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def print_section(title: str) -> None:
    print(f"\n{'─' * 60}")
    print(f"  {title}")
    print('─' * 60)


def main():
    print_section("🏥 Multimodal Medical Risk Assessment — Demo")

    # ── Load engine ───────────────────────────────────────────────────────
    from src.inference_engine import MedicalRiskEngine
    from src.utils.helpers import setup_logging
    setup_logging("WARNING")   # suppress model-loading logs in demo

    print("\n[1/3] Loading models (first run may take a few minutes)…")
    t0 = time.perf_counter()
    engine = MedicalRiskEngine()
    print(f"      Models ready in {(time.perf_counter() - t0)*1000:.0f}ms")

    # ── Synthetic image ───────────────────────────────────────────────────
    print("\n[2/3] Generating synthetic chest X-ray…")
    xray = make_synthetic_xray()
    xray.save("demo_xray.png")
    print("      Saved → demo_xray.png")
    b64_img = image_to_b64(xray)

    # ── Run assessments ───────────────────────────────────────────────────
    test_cases = [
        {
            "name": "Pneumonia-like presentation",
            "symptoms": "fever, cough, chest pain, shortness of breath",
        },
        {
            "name": "Rare disease pattern",
            "symptoms": "hemoptysis, renal failure, granuloma, vasculitis",
        },
        {
            "name": "Low-risk / No symptoms",
            "symptoms": "",
        },
        {
            "name": "Cardiac presentation",
            "symptoms": "edema, dyspnea, fatigue, orthopnea",
        },
    ]

    print("\n[3/3] Running assessments…\n")

    for case in test_cases:
        print_section(f"🔍 Case: {case['name']}")
        print(f"  Symptoms: {case['symptoms'] or '(none)'}")

        result = engine.predict(
            image_b64=b64_img,
            symptoms=case["symptoms"],
        )

        risk_emoji = {"Low": "🟢", "Moderate": "🟡", "High": "🟠", "Critical": "🔴"}.get(
            result.risk_label, "⚪"
        )

        print(f"\n  {risk_emoji} Risk Label    : {result.risk_label}")
        print(f"     Risk Score    : {result.risk_score:.4f}  (±{result.risk_uncertainty:.4f})")
        print(f"     Primary Dx    : {result.primary_disease}")
        print(f"     Inference     : {result.inference_time_ms:.0f}ms")

        exp = result.explanation
        print(f"\n  📋 Differential Diagnoses:")
        for dd in exp.get("differential_diagnoses", [])[:3]:
            bar = "█" * int(dd["probability"] / 5)
            print(f"     {dd['disease']:<30} {bar:<20} {dd['probability']:.1f}%")

        if result.top_symptoms:
            print(f"\n  💊 Top Symptoms:")
            for s in result.top_symptoms[:3]:
                bar = "█" * int(s["importance"] * 10)
                print(f"     {s['symptom']:<30} {bar:<10} {s['importance']:.3f}")

        gard = result.gard_enrichment
        if gard.get("rare_candidates"):
            print(f"\n  🧬 GARD Rare Candidates:")
            for rc in gard["rare_candidates"][:2]:
                print(f"     {rc['name']} ({rc['id']}) — score: {rc['match_score']:.3f}")

        print(f"\n  📝 Summary:")
        summary = exp.get("summary", "")
        for line in [summary[i:i+72] for i in range(0, len(summary), 72)]:
            print(f"     {line}")

    # ── Save full JSON output of last result ──────────────────────────────
    print_section("💾 Full JSON Output (last result)")
    output = result.to_dict()
    with open("demo_output.json", "w") as f:
        json.dump(output, f, indent=2)
    print("  Saved → demo_output.json")

    # ── Batch demo ────────────────────────────────────────────────────────
    print_section("📦 Batch Prediction Demo")
    batch_requests = [
        {"image_base64": b64_img, "symptoms": "fever, cough"},
        {"image_base64": b64_img, "symptoms": "chest pain, edema"},
        {"image_base64": b64_img, "symptoms": ""},
    ]
    t_batch = time.perf_counter()
    batch_results = engine.predict_batch(batch_requests)
    t_batch_ms = (time.perf_counter() - t_batch) * 1000
    print(f"  {len(batch_results)} assessments completed in {t_batch_ms:.0f}ms")
    for i, r in enumerate(batch_results):
        emoji = {"Low": "🟢", "Moderate": "🟡", "High": "🟠", "Critical": "🔴"}.get(r.risk_label, "⚪")
        print(f"  [{i+1}] {emoji} {r.risk_label:10s}  {r.primary_disease}")

    print("\n✅ Demo complete.\n")


if __name__ == "__main__":
    main()
