"""
src/utils/preprocessing.py
Unified preprocessing pipeline: images → tensors, symptoms → token IDs.
"""

import logging
from typing import Dict, Optional, Tuple

import numpy as np
import torch
from PIL import Image
from torchvision import transforms
from transformers import AutoTokenizer

from configs.config import APP_CONFIG
from src.utils.helpers import (
    clean_symptom_text,
    decode_base64_image,
    extract_symptom_tokens,
    resize_and_pad,
    validate_image,
)

logger = logging.getLogger(__name__)

cfg = APP_CONFIG.preprocessing


# ─────────────────────── Image transforms ────────────────────────────────────

class ImagePreprocessor:
    """
    Handles:
      • base64 decode → PIL
      • resize + pad to square
      • normalise to BiomedCLIP stats
    """

    def __init__(self, image_size: int = cfg.image_size):
        self.image_size = image_size
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size), interpolation=transforms.InterpolationMode.BICUBIC),
            transforms.ToTensor(),
            transforms.Normalize(mean=cfg.image_mean, std=cfg.image_std),
        ])

    def from_pil(self, image: Image.Image) -> torch.Tensor:
        valid, msg = validate_image(image)
        if not valid:
            raise ValueError(msg)
        image = resize_and_pad(image, self.image_size)
        return self.transform(image).unsqueeze(0)          # [1, C, H, W]

    def from_base64(self, b64: str) -> Tuple[torch.Tensor, Image.Image]:
        pil = decode_base64_image(b64)
        tensor = self.from_pil(pil)
        return tensor, pil

    def from_filepath(self, path: str) -> Tuple[torch.Tensor, Image.Image]:
        pil = Image.open(path).convert("RGB")
        return self.from_pil(pil), pil


# ─────────────────────── Text tokeniser ──────────────────────────────────────

class TextPreprocessor:
    """
    Wraps HuggingFace tokeniser for BioBERT.
    Also exposes cleaned symptom tokens for explainability.
    """

    def __init__(
        self,
        model_name: str = APP_CONFIG.model.biobert_model_name,
        max_length: int = APP_CONFIG.model.biobert_max_length,
    ):
        self.max_length = max_length
        logger.info(f"Loading tokeniser: {model_name}")
        try:
            self.tokeniser = AutoTokenizer.from_pretrained(
                model_name,
                cache_dir=APP_CONFIG.model.cache_dir,
            )
        except Exception as e:
            logger.warning(f"Could not load {model_name}: {e}. Falling back to bert-base-cased.")
            self.tokeniser = AutoTokenizer.from_pretrained(
                "bert-base-cased",
                cache_dir=APP_CONFIG.model.cache_dir,
            )

    def __call__(self, text: str) -> Dict[str, torch.Tensor]:
        cleaned = clean_symptom_text(text)
        if not cleaned:
            cleaned = "[MASK]"            # sentinel for empty input
        encoding = self.tokeniser(
            cleaned,
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt",
        )
        return encoding                   # input_ids, attention_mask, token_type_ids

    def get_tokens(self, text: str) -> list:
        """Return human-readable word-piece tokens (excluding specials)."""
        cleaned = clean_symptom_text(text)
        tokens = self.tokeniser.tokenize(cleaned)
        return [t for t in tokens if not t.startswith("##") and t not in ("[CLS]", "[SEP]", "[PAD]")]

    def get_symptom_list(self, text: str) -> list:
        return extract_symptom_tokens(clean_symptom_text(text))
