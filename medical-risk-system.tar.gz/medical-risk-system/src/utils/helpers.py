"""
src/utils/helpers.py
Shared utility functions for the Medical Risk Assessment System.
"""

import base64
import io
import logging
import re
import time
import unicodedata
from functools import wraps
from typing import Optional, Tuple

import numpy as np
from PIL import Image

logger = logging.getLogger(__name__)


# ─────────────────────────────── Logging ────────────────────────────────────

def setup_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        level=getattr(logging, level.upper(), logging.INFO),
    )


def timeit(func):
    """Decorator: log execution time of any function."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        t0 = time.perf_counter()
        result = func(*args, **kwargs)
        elapsed = time.perf_counter() - t0
        logger.debug(f"{func.__qualname__} took {elapsed:.3f}s")
        return result
    return wrapper


# ─────────────────────────────── Image ──────────────────────────────────────

def decode_base64_image(b64_string: str) -> Image.Image:
    """
    Decode a base64-encoded image string to a PIL Image.
    Strips data-URI prefix if present (e.g. 'data:image/png;base64,...').
    """
    # Remove data-URI header if present
    if "," in b64_string:
        b64_string = b64_string.split(",", 1)[1]
    # Fix padding
    padding = 4 - len(b64_string) % 4
    if padding != 4:
        b64_string += "=" * padding
    try:
        image_bytes = base64.b64decode(b64_string)
        image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        return image
    except Exception as e:
        raise ValueError(f"Failed to decode base64 image: {e}") from e


def encode_image_to_base64(image: Image.Image, fmt: str = "PNG") -> str:
    """Encode a PIL Image to a base64 string."""
    buffer = io.BytesIO()
    image.save(buffer, format=fmt)
    return base64.b64encode(buffer.getvalue()).decode("utf-8")


def resize_and_pad(image: Image.Image, target_size: int = 224) -> Image.Image:
    """
    Resize image maintaining aspect ratio, then center-pad to target_size×target_size.
    Background is filled with mean grey (127).
    """
    w, h = image.size
    scale = target_size / max(w, h)
    new_w, new_h = int(w * scale), int(h * scale)
    image = image.resize((new_w, new_h), Image.LANCZOS)

    padded = Image.new("RGB", (target_size, target_size), (127, 127, 127))
    offset = ((target_size - new_w) // 2, (target_size - new_h) // 2)
    padded.paste(image, offset)
    return padded


def validate_image(image: Image.Image) -> Tuple[bool, str]:
    """Basic sanity checks on the decoded image."""
    if image is None:
        return False, "Image is None."
    w, h = image.size
    if w < 32 or h < 32:
        return False, f"Image too small: {w}×{h} (min 32×32)."
    if w > 8192 or h > 8192:
        return False, f"Image too large: {w}×{h} (max 8192×8192)."
    return True, "OK"


# ─────────────────────────────── Text ───────────────────────────────────────

# Medical abbreviation expansion table
MEDICAL_ABBR = {
    "sob": "shortness of breath",
    "cp": "chest pain",
    "htn": "hypertension",
    "dm": "diabetes mellitus",
    "cad": "coronary artery disease",
    "mi": "myocardial infarction",
    "chf": "congestive heart failure",
    "copd": "chronic obstructive pulmonary disease",
    "uri": "upper respiratory infection",
    "uti": "urinary tract infection",
    "n/v": "nausea vomiting",
    "nv": "nausea vomiting",
    "ha": "headache",
    "abd": "abdominal",
    "r/o": "rule out",
}

_NOISE_RE = re.compile(r"[^a-z0-9\s,./'-]")
_MULTI_SPACE_RE = re.compile(r"\s+")


def clean_symptom_text(text: str) -> str:
    """
    Normalise and clean symptom text:
      1. Unicode normalise → ASCII where possible
      2. Lower-case
      3. Expand common medical abbreviations
      4. Strip non-medical punctuation / noise
      5. Collapse whitespace
    """
    if not text or not text.strip():
        return ""

    # Normalise unicode (é → e, etc.)
    text = unicodedata.normalize("NFKD", text)
    text = text.encode("ascii", "ignore").decode("ascii")
    text = text.lower().strip()

    # Expand abbreviations (whole-word match)
    for abbr, expansion in MEDICAL_ABBR.items():
        text = re.sub(rf"\b{re.escape(abbr)}\b", expansion, text)

    # Remove noisy characters
    text = _NOISE_RE.sub(" ", text)
    text = _MULTI_SPACE_RE.sub(" ", text).strip()
    return text


def extract_symptom_tokens(text: str) -> list:
    """Split cleaned symptom string into individual symptom tokens."""
    # Split on commas / semicolons / 'and'
    tokens = re.split(r"[,;]|\band\b", text)
    return [t.strip() for t in tokens if t.strip()]


# ─────────────────────────────── Numeric ────────────────────────────────────

def sigmoid(x: float) -> float:
    return 1.0 / (1.0 + np.exp(-x))


def softmax(x: np.ndarray) -> np.ndarray:
    e = np.exp(x - x.max())
    return e / e.sum()


def clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, value))
